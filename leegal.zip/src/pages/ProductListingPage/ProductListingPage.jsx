import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import {
  getProducts,
  getCategories,
  getProductsByCategory,
} from "../../api/productApi";

import Navbar from "../../components/Navbar/Navbar";
import SidebarFilters from "../../components/SidebarFilters/SidebarFilters";
import ProductCard from "../../components/ProductCard/ProductCard";
import Pagination from "../../components/Pagination/Pagination";
import Loader from "../../components/Loader/Loader";
import ErrorState from "../../components/ErrorState/ErrorState";

import "./ProductListingPage.css";

const ProductListingPage = () => {
  // 1. Raw API Data Storage States
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  /* ==========================================================================
     URL SEARCH PARAMETERS LAYER (Handles State Persistence across Page Routing)
     ========================================================================== */
  const [searchParams, setSearchParams] = useSearchParams();

  // Read current configuration parameters right out of the URL string
  const selectedCategory = searchParams.get("category") || "";
  const minPrice = searchParams.get("minPrice") || "";
  const maxPrice = searchParams.get("maxPrice") || "";

  // Parse string back into array layout structures smoothly ("Apple,Samsung" -> ["Apple", "Samsung"])
  const selectedBrandsString = searchParams.get("brands");
  const selectedBrands = selectedBrandsString
    ? selectedBrandsString.split(",")
    : [];

  const currentPage = parseInt(searchParams.get("page") || "1", 10);
  const PRODUCTS_PER_PAGE = 12;

  /* ==========================================================================
     URL State Synchronizer Engine
     ========================================================================== */
  const updateFilters = (newParams) => {
    // Create a fresh clone of our existing URL parameters
    const updated = new URLSearchParams(searchParams);

    Object.keys(newParams).forEach((key) => {
      const value = newParams[key];

      // Only perform logic if the parameter is explicitly defined
      if (value !== undefined) {
        if (value === "" || (Array.isArray(value) && value.length === 0)) {
          updated.delete(key); // Safe delete since it was explicitly passed as empty
        } else {
          updated.set(key, Array.isArray(value) ? value.join(",") : value);
        }
      }
    });

    // Reset pagination back to page 1 automatically when non-page filters shift
    if (!newParams.hasOwnProperty("page")) {
      updated.set("page", "1");
    }

    setSearchParams(updated);
  };

  /* ==========================================================================
     State Mapping Wrappers passed explicitly to child component elements
     ========================================================================== */
  const setSelectedCategory = (category) => updateFilters({ category });

  // COMBINED FIX: Updates both parameters together to prevent async race conditions
  const setPriceRange = (min, max) =>
    updateFilters({ minPrice: min, maxPrice: max });

  const setSelectedBrands = (brandsArr) => updateFilters({ brands: brandsArr });
  const setCurrentPage = (page) => updateFilters({ page });

  // Fetch initial category options checkbox array elements on layout mounting
  useEffect(() => {
    const fetchCategoriesData = async () => {
      try {
        const response = await getCategories();
        setCategories(Array.isArray(response.data) ? response.data : []);
      } catch (err) {
        console.error("Failed to fetch sidebar category metrics:", err);
      }
    };
    fetchCategoriesData();
  }, []);

  // Fetch product dataset arrays if a specific category parameter shifts
  useEffect(() => {
    const fetchProductsData = async () => {
      try {
        setLoading(true);
        setError("");

        let response;
        if (selectedCategory) {
          response = await getProductsByCategory(selectedCategory);
        } else {
          // Grabs 100 base items so combined multi-brand selectors slice smoothly on client-side arrays
          response = await getProducts(100);
        }

        setProducts(response.data.products || []);
      } catch (err) {
        setError(
          "Failed to load catalog products. Please check connection status."
        );
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchProductsData();
  }, [selectedCategory]);

  /* ==========================================================================
     ENGINE PROCESSING: Client-Side Combined Filters Evaluation Core
     ========================================================================== */
  const filteredProducts = products.filter((product) => {
    const price = Number(product.price);

    // Confirms the state parameters parse perfectly into numeric evaluations
    const matchesMinPrice = minPrice === "" || price >= parseFloat(minPrice);
    const matchesMaxPrice = maxPrice === "" || price <= parseFloat(maxPrice);
    const matchesBrand =
      selectedBrands.length === 0 || selectedBrands.includes(product.brand);

    return matchesMinPrice && matchesMaxPrice && matchesBrand;
  });

  /* ==========================================================================
     PAGINATION RENDER CALCULATOR SLICE
     ========================================================================== */
  const indexOfLastProduct = currentPage * PRODUCTS_PER_PAGE;
  const indexOfFirstProduct = indexOfLastProduct - PRODUCTS_PER_PAGE;
  const currentProductsToDisplay = filteredProducts.slice(
    indexOfFirstProduct,
    indexOfLastProduct
  );
  const totalPages = Math.ceil(filteredProducts.length / PRODUCTS_PER_PAGE);

  // Extract unique brands dynamically from current loaded target collection
  const uniqueBrands = [
    ...new Set(products.map((p) => p.brand).filter(Boolean)),
  ];

  return (
    <div className="app-window-frame">
      <Navbar />

      <div className="main-layout-container">
        <SidebarFilters
          categories={categories}
          selectedCategory={selectedCategory}
          setSelectedCategory={setSelectedCategory}
          minPrice={minPrice}
          maxPrice={maxPrice}
          setPriceRange={setPriceRange}
          brands={uniqueBrands}
          selectedBrands={selectedBrands}
          setSelectedBrands={setSelectedBrands}
        />

        <div className="content-space">
          {loading && <Loader />}
          {error && <ErrorState message={error} />}

          {!loading && !error && (
            <>
              <div className="product-grid">
                {currentProductsToDisplay.length > 0 ? (
                  currentProductsToDisplay.map((product) => (
                    <ProductCard key={product.id} product={product} />
                  ))
                ) : (
                  <div className="no-products-container">
                    No products match your selected filter options.
                  </div>
                )}
              </div>

              {totalPages > 1 && (
                <Pagination
                  currentPage={currentPage}
                  totalPages={totalPages}
                  onPageChange={(page) => setCurrentPage(page)}
                />
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProductListingPage;
